from django.apps import AppConfig


class LoginRegisterConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_Register'
